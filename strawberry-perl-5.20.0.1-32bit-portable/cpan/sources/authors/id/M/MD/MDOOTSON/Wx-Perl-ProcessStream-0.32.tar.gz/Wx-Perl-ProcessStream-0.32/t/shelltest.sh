#!/bin/sh

printf "WXTEST INPUT"

read MYINPUT

echo "ECHO:$MYINPUT"

