#!perl
use strict;
use warning;

my $x = 23;

# problem: warnings with an s at the end.
