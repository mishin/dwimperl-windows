The icons in the gnome218 directory are taken from the gnome-icon-theme
project, version 2.18.

ftp://ftp.gnome.org/pub/gnome/sources/gnome-icon-theme/2.18/gnome-icon-theme-2.18.0.tar.bz2

The date of the above file is in 2007, so the copyright should be from about
that time.

Authors:
    Lapo Calamandrei <calamandrei@gmail.com>
    Rodney Dawes <dobey@novell.com>
    Luca Ferretti <elle.uca@libero.it>
    Tuomas Kuosmanen <tigert@gimp.org>
    Andreas Nilsson <nisses.mail@home.se>
    Jakub Steiner <jimmac@novell.com>

License:
   This package is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; version 2 dated June, 1991.

   This package is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this package; if not, write to the Free Software
   Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA 02110-1301,
   USA.
