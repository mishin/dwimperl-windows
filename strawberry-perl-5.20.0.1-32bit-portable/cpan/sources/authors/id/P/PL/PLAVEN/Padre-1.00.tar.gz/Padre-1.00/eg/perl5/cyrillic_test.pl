#!/usr/bin/perl -w
use strict;

# This is some cyrillic test, encoded in UTF8
# Това е тестова програма за изпробване на поддръжката
# на UTF8 от Падре

sub test()
{
    print "Hi!\n";
}

test;
