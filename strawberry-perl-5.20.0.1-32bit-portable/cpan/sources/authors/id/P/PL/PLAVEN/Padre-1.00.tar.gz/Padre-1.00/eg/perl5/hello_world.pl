#!/usr/bin/perl

use 5.008;
use strict;
use warnings;

$| = 1;

print "Hello world\n";
print "More text";
