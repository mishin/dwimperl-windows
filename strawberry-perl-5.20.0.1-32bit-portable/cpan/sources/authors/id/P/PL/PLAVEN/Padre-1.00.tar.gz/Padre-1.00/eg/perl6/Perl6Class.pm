use Something;

class Mine does Something {
}

