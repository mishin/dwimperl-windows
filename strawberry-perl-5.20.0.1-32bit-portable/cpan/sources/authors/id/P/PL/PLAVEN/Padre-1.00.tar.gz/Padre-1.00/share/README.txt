Note to Packagers:

This directory contains general padre-specific imagery, all of which have
either been created from scratch by members of the Padre team as described
below (they fall under the same terms as Perl(!) itself) or have their
source individually documented and verified with licensing information
below.

Note to Developers:

Make damn sure it stays that way!

Images:

=============================
padre-splash.png
=============================

Made specifically for use in Padre and debian.

Copyright 2009 Ahmad M. Zawawi
You can redistribute and/or modify the icons under the same terms as Perl itself.

=============================
padre-splash-ccnc.png
=============================

Original source http://www.flickr.com/photos/blackbutterfly/3257936873/

This image is was originally distributed (and is redistributed) under the terms
of the Attribution-Noncommercial-Share Alike 2.0 Generic.

http://creativecommons.org/licenses/by-nc-sa/2.0/deed.en
