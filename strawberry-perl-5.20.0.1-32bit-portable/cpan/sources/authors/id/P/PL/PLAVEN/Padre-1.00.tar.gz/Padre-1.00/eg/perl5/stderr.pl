#!/usr/bin/perl

use 5.008;
use strict;
use warnings;

$| = 1;

print "On STDOUT\n";
print STDERR "On STDERR\n";
print "On STDOUT 2\n";
print STDERR "On STDERR 2\n";
