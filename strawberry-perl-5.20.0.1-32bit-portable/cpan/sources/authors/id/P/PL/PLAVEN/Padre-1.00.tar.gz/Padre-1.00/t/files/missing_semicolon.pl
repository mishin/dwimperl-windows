#!/usr/bin/perl
use strict;
use warnings;

my $x

if ($x) {
	print "ok";
}