
a = 19
b = 23
c = a + b
puts c

