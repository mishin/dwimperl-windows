#!/usr/bin/perl
use warnings;

$what = 42;

