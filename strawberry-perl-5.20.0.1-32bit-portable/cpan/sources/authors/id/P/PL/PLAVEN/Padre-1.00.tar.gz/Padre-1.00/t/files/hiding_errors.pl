use strict;
use warnings;
#use CGI::Carp qw(fatalsToBrowser);

my no_such_sub


# see ticket #1203
# if the # removed from line 3 te syntax checker of Padre shows
# that there are errors but does not show the actual errors

