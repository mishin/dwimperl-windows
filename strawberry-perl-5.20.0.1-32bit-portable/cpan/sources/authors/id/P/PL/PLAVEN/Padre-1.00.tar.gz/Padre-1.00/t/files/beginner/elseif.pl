#!/usr/bin/perl

use 5.006;
use strict;
use warnings;


if (1) {
} elseif (2) {
}