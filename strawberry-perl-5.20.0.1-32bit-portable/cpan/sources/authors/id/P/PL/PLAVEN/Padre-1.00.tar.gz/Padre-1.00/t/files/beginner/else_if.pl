#!/usr/bin/perl

use 5.006;
use strict;
use warnings;


if (1) {
} else if (2) {
}