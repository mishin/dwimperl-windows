use strict;
use warnings;

my $string = 'tada';
kaboom

my $length = 5;
