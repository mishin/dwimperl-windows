package Padre::Plugin::A;
use strict;
use warnings FATAL => 'all';

our $VERSION = '0.01';

print $syntax_error;

1;


