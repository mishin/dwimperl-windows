#!/usr/bin/perl
use strict;
use warnings;

my $name;

print "Hello $name\n";
my $x = "2x";
print 3+$x, "\n";

print "done\n";
