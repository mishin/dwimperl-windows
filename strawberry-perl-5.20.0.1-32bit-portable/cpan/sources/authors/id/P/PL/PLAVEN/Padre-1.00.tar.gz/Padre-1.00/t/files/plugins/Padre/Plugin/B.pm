package Padre::Plugin::B;
use strict;
use warnings FATAL => 'all';

our $VERSION = '0.01';


1;


