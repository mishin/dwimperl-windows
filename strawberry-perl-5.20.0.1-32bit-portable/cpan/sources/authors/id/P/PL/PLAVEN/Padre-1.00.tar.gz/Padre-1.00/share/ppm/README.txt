This directory is used by the ppm client to store temporary files
