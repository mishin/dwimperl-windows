#!perl 
use strict;
use warnings;

my @ARGV = ("one");

# problem: user should not declare @ARGV with my
