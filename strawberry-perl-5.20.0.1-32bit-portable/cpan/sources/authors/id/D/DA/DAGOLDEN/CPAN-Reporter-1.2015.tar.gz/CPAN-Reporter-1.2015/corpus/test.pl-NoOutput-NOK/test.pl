# Bogus::Pass tests
use strict;

exit 1;
