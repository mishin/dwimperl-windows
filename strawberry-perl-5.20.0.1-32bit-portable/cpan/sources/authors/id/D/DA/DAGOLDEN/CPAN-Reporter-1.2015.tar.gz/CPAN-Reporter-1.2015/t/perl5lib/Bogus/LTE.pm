package Bogus::LTE;
$VERSION = 3.14;
use strict;
1;
