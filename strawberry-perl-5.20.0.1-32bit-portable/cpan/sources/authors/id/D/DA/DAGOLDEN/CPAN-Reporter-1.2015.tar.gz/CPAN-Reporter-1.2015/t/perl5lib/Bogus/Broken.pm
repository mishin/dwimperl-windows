package Bogus::Broken;
$VERSION = 3.14;
use strict;
use FuddleDuddleCantFindMe;
1;

