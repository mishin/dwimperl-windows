# Bogus::Pass tests
use strict;

use Test::More;

plan tests =>  1 ;

fail( "Failed this test" );
