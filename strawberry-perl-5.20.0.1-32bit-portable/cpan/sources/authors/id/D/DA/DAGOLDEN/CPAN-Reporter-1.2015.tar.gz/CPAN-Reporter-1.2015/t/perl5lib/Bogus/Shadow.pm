package Bogus::Shadow;
$VERSION = 3.14;
use strict;
1;
