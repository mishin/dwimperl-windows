package Bogus::Shadow;
$VERSION = 2.72;
use strict;
1;
