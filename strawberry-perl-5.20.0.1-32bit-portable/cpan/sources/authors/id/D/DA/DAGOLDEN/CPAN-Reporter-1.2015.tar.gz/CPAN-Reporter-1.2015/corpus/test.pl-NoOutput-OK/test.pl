# Bogus::Pass tests
use strict;

exit;
