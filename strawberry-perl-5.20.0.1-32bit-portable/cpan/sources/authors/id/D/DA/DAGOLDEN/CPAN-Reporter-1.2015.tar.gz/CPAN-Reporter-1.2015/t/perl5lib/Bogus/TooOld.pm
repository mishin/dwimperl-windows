package Bogus::TooOld;
$VERSION = 0.01;
use strict;
1;
