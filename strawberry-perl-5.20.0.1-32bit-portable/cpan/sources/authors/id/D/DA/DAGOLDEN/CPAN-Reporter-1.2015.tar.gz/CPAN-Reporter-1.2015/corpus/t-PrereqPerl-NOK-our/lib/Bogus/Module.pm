package Bogus::Module;

our $VERSION     = "0.01";

1; # modules must be true

