package Bogus::NoVersion;
use strict;
1;
