# Bogus::Pass tests
use strict;

use File::Spec 99999.9;

plan tests =>  1 ;

pass( "Passed this test" );
