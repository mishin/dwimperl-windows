# Bogus::Pass tests
use strict;
use Bogus::Module::Doesnt::Exist;

use Test::More;

plan tests =>  1 ;

pass( "Passed this test" );
