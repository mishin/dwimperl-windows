package TestApp3::Plugin::Dies2;

use Moose::Role;
die 'oh noes';

1;
